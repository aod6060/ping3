
#define NAMESPACE HIDRAW
#include "hid.c"
